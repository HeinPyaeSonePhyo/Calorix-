const foods = [
  // Breakfast
  { id: 1, name: 'Oatmeal', category: 'Breakfast', portion: '1 bowl (240g)', calories: 150, protein: 5, carbs: 27, fat: 3, custom: false },
  { id: 2, name: 'Boiled Eggs', category: 'Breakfast', portion: '2 eggs (100g)', calories: 140, protein: 12, carbs: 1, fat: 10, custom: false },
  { id: 3, name: 'Avocado Toast', category: 'Breakfast', portion: '1 slice (180g)', calories: 280, protein: 8, carbs: 30, fat: 15, custom: false },
  { id: 4, name: 'Greek Yogurt', category: 'Breakfast', portion: '1 cup (200g)', calories: 130, protein: 17, carbs: 9, fat: 1, custom: false },
  { id: 5, name: 'Pancakes', category: 'Breakfast', portion: '3 medium (150g)', calories: 350, protein: 9, carbs: 56, fat: 11, custom: false },
  { id: 6, name: 'Granola with Milk', category: 'Breakfast', portion: '1 bowl (250g)', calories: 420, protein: 11, carbs: 64, fat: 14, custom: false },
  { id: 7, name: 'Scrambled Eggs', category: 'Breakfast', portion: '2 eggs (120g)', calories: 180, protein: 13, carbs: 2, fat: 13, custom: false },
  { id: 8, name: 'Banana Smoothie', category: 'Breakfast', portion: '1 glass (300ml)', calories: 210, protein: 6, carbs: 42, fat: 2, custom: false },

  // Lunch
  { id: 9, name: 'Grilled Chicken Salad', category: 'Lunch', portion: '1 plate (300g)', calories: 350, protein: 40, carbs: 12, fat: 14, custom: false },
  { id: 10, name: 'Tuna Sandwich', category: 'Lunch', portion: '1 sandwich (200g)', calories: 310, protein: 25, carbs: 38, fat: 7, custom: false },
  { id: 11, name: 'Lentil Soup', category: 'Lunch', portion: '1 bowl (350g)', calories: 230, protein: 15, carbs: 38, fat: 1, custom: false },
  { id: 12, name: 'Caesar Salad', category: 'Lunch', portion: '1 plate (250g)', calories: 290, protein: 10, carbs: 18, fat: 21, custom: false },
  { id: 13, name: 'Turkey Wrap', category: 'Lunch', portion: '1 wrap (220g)', calories: 370, protein: 28, carbs: 44, fat: 10, custom: false },
  { id: 14, name: 'Vegetable Stir Fry', category: 'Lunch', portion: '1 bowl (280g)', calories: 200, protein: 8, carbs: 32, fat: 6, custom: false },
  { id: 15, name: 'Pasta Primavera', category: 'Lunch', portion: '1 bowl (300g)', calories: 430, protein: 14, carbs: 72, fat: 12, custom: false },

  // Dinner
  { id: 16, name: 'Rice and Chicken Bowl', category: 'Dinner', portion: '1 bowl (400g)', calories: 520, protein: 38, carbs: 62, fat: 12, custom: false },
  { id: 17, name: 'Grilled Salmon', category: 'Dinner', portion: '1 fillet (180g)', calories: 360, protein: 40, carbs: 0, fat: 22, custom: false },
  { id: 18, name: 'Beef Stir Fry', category: 'Dinner', portion: '1 plate (350g)', calories: 480, protein: 35, carbs: 40, fat: 18, custom: false },
  { id: 19, name: 'Vegetarian Curry', category: 'Dinner', portion: '1 bowl (380g)', calories: 340, protein: 12, carbs: 55, fat: 10, custom: false },
  { id: 20, name: 'Spaghetti Bolognese', category: 'Dinner', portion: '1 plate (380g)', calories: 590, protein: 32, carbs: 78, fat: 18, custom: false },
  { id: 21, name: 'Grilled Chicken Breast', category: 'Dinner', portion: '1 piece (200g)', calories: 310, protein: 58, carbs: 0, fat: 7, custom: false },
  { id: 22, name: 'Baked Cod with Veg', category: 'Dinner', portion: '1 plate (320g)', calories: 290, protein: 35, carbs: 22, fat: 6, custom: false },
  { id: 23, name: 'Mushroom Risotto', category: 'Dinner', portion: '1 bowl (350g)', calories: 470, protein: 12, carbs: 76, fat: 14, custom: false },

  // Snack
  { id: 24, name: 'Banana', category: 'Snack', portion: '1 medium (120g)', calories: 105, protein: 1, carbs: 27, fat: 0, custom: false },
  { id: 25, name: 'Apple', category: 'Snack', portion: '1 medium (180g)', calories: 95, protein: 0, carbs: 25, fat: 0, custom: false },
  { id: 26, name: 'Mixed Nuts', category: 'Snack', portion: '30g handful', calories: 180, protein: 5, carbs: 6, fat: 16, custom: false },
  { id: 27, name: 'Protein Bar', category: 'Snack', portion: '1 bar (60g)', calories: 210, protein: 20, carbs: 22, fat: 7, custom: false },
  { id: 28, name: 'Hummus & Carrots', category: 'Snack', portion: '1 serving (120g)', calories: 150, protein: 5, carbs: 18, fat: 7, custom: false },
  { id: 29, name: 'Rice Cakes', category: 'Snack', portion: '3 cakes (30g)', calories: 110, protein: 2, carbs: 23, fat: 1, custom: false },
  { id: 30, name: 'Dark Chocolate', category: 'Snack', portion: '2 squares (20g)', calories: 112, protein: 1, carbs: 10, fat: 7, custom: false },

  // Drink
  { id: 31, name: 'Orange Juice', category: 'Drink', portion: '1 glass (240ml)', calories: 112, protein: 2, carbs: 26, fat: 0, custom: false },
  { id: 32, name: 'Whole Milk', category: 'Drink', portion: '1 cup (240ml)', calories: 149, protein: 8, carbs: 12, fat: 8, custom: false },
  { id: 33, name: 'Protein Shake', category: 'Drink', portion: '1 shake (350ml)', calories: 250, protein: 30, carbs: 20, fat: 5, custom: false },
  { id: 34, name: 'Latte', category: 'Drink', portion: '1 medium (350ml)', calories: 190, protein: 10, carbs: 20, fat: 7, custom: false },
  { id: 35, name: 'Green Smoothie', category: 'Drink', portion: '1 glass (300ml)', calories: 140, protein: 3, carbs: 28, fat: 2, custom: false },
];

export default foods;