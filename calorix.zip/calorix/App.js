import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';
import { Ionicons } from '@expo/vector-icons';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { StyleSheet } from 'react-native';

import SplashScreen from './screens/Splash';
import DashboardScreen from './screens/Dashboard';
import FoodLibraryScreen from './screens/FoodLibrary';
import FoodDetailScreen from './screens/FoodDetail';
import LogScreen from './screens/LogDay';
import AddFoodScreen from './screens/AddFood';
import FavouritesScreen from './screens/Favourites';
import ProfileScreen from './screens/Profile';

const Tab = createBottomTabNavigator();
const LibraryStack = createStackNavigator();
const LogStack = createStackNavigator();

function LibraryStackNav() {
  return (
    <LibraryStack.Navigator screenOptions={{ headerShown: false }}>
      <LibraryStack.Screen name="FoodLibrary" component={FoodLibraryScreen} />
      <LibraryStack.Screen name="FoodDetail" component={FoodDetailScreen} />
      <LibraryStack.Screen name="AddFood" component={AddFoodScreen} />
    </LibraryStack.Navigator>
  );
}

function LogStackNav() {
  return (
    <LogStack.Navigator screenOptions={{ headerShown: false }}>
      <LogStack.Screen name="Log" component={LogScreen} />
    </LogStack.Navigator>
  );
}

function MainApp() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: '#4F46E5',
        tabBarInactiveTintColor: '#9CA3AF',
        tabBarStyle: {
          backgroundColor: '#fff',
          borderTopColor: '#E5E7EB',
          height: 60,
          paddingBottom: 8,
          paddingTop: 6,
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
        tabBarIcon: ({ color, size }) => {
          const icons = {
            Dashboard: 'home',
            Library: 'restaurant',
            'My Log': 'list',
            Favourites: 'heart',
            Profile: 'person',
          };
          return <Ionicons name={icons[route.name]} size={size} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Dashboard" component={DashboardScreen} />
      <Tab.Screen name="Library" component={LibraryStackNav} />
      <Tab.Screen name="My Log" component={LogStackNav} />
      <Tab.Screen name="Favourites" component={FavouritesScreen} />
      <Tab.Screen name="Profile" component={ProfileScreen} />
    </Tab.Navigator>
  );
}

export default function App() {
  const [showSplash, setShowSplash] = useState(true);

  if (showSplash) {
    return (
      <GestureHandlerRootView style={styles.root}>
        <StatusBar style="light" />
        <SplashScreen onDone={() => setShowSplash(false)} />
      </GestureHandlerRootView>
    );
  }

  return (
    <GestureHandlerRootView style={styles.root}>
      <NavigationContainer>
        <StatusBar style="dark" />
        <MainApp />
      </NavigationContainer>
    </GestureHandlerRootView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
});