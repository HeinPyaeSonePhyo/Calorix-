import AsyncStorage from '@react-native-async-storage/async-storage';

const LOG_KEY = 'calorix_log';
const FAVS_KEY = 'calorix_favs';
const CUSTOM_KEY = 'calorix_custom';
const GOAL_KEY = 'calorix_goal';

export const getTodayKey = () => {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
};

// ---- Log ----
export const getLog = async () => {
  try {
    const raw = await AsyncStorage.getItem(LOG_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
};

export const getTodayLog = async () => {
  const log = await getLog();
  return log[getTodayKey()] || [];
};

export const addToLog = async (entry) => {
  const log = await getLog();
  const key = getTodayKey();
  const today = log[key] || [];
  today.push({ ...entry, logId: Date.now(), loggedAt: new Date().toISOString() });
  log[key] = today;
  await AsyncStorage.setItem(LOG_KEY, JSON.stringify(log));
};

export const removeFromLog = async (logId) => {
  const log = await getLog();
  const key = getTodayKey();
  const today = log[key] || [];
  log[key] = today.filter((e) => e.logId !== logId);
  await AsyncStorage.setItem(LOG_KEY, JSON.stringify(log));
};

// ---- Favourites ----
export const getFavourites = async () => {
  try {
    const raw = await AsyncStorage.getItem(FAVS_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const toggleFavourite = async (foodId) => {
  const favs = await getFavourites();
  const idx = favs.indexOf(foodId);
  if (idx === -1) favs.push(foodId);
  else favs.splice(idx, 1);
  await AsyncStorage.setItem(FAVS_KEY, JSON.stringify(favs));
  return favs;
};

// ---- Custom Foods ----
export const getCustomFoods = async () => {
  try {
    const raw = await AsyncStorage.getItem(CUSTOM_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
};

export const saveCustomFood = async (food) => {
  const customs = await getCustomFoods();
  const newFood = { ...food, id: `c_${Date.now()}`, custom: true };
  customs.push(newFood);
  await AsyncStorage.setItem(CUSTOM_KEY, JSON.stringify(customs));
  return newFood;
};

export const deleteCustomFood = async (id) => {
  const customs = await getCustomFoods();
  const updated = customs.filter((f) => f.id !== id);
  await AsyncStorage.setItem(CUSTOM_KEY, JSON.stringify(updated));
};

// ---- Daily Goal ----
export const getDailyGoal = async () => {
  try {
    const raw = await AsyncStorage.getItem(GOAL_KEY);
    return raw ? parseInt(raw) : 2200;
  } catch {
    return 2200;
  }
};

export const setDailyGoal = async (kcal) => {
  await AsyncStorage.setItem(GOAL_KEY, String(kcal));
};

// ---- User Profile ----
const PROFILE_KEY = 'calorix_profile';

export const getProfile = async () => {
  try {
    const raw = await AsyncStorage.getItem(PROFILE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
};

export const saveProfile = async (profile) => {
  await AsyncStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
};
