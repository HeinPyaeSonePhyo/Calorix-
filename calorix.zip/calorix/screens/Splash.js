import React, { useEffect, useRef } from 'react';
import {
  View, Text, StyleSheet, Animated, Dimensions, TouchableOpacity,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

const { width } = Dimensions.get('window');

export default function SplashScreen({ onDone }) {
  const logoScale   = useRef(new Animated.Value(0.6)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const textY       = useRef(new Animated.Value(15)).current;
  const textOpacity = useRef(new Animated.Value(0)).current;
  const btnOpacity  = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.parallel([
        Animated.spring(logoScale, { toValue: 1, friction: 5, tension: 80, useNativeDriver: true }),
        Animated.timing(logoOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
      ]),
      Animated.parallel([
        Animated.timing(textOpacity, { toValue: 1, duration: 450, useNativeDriver: true }),
        Animated.timing(textY, { toValue: 0, duration: 450, useNativeDriver: true }),
      ]),
      Animated.delay(300),
      Animated.timing(btnOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
    ]).start();
  }, []);

  const handleEnter = () => {
    Animated.timing(logoOpacity, { toValue: 0, duration: 300, useNativeDriver: true }).start(() => onDone());
  };

  return (
    <View style={styles.container}>

      {/* Logo */}
      <Animated.View style={[styles.logoWrap, { transform: [{ scale: logoScale }], opacity: logoOpacity }]}>
        <Ionicons name="flame" size={50} color="#fff" />
      </Animated.View>

      {/* Title */}
      <Animated.Text style={[styles.title, { opacity: textOpacity, transform: [{ translateY: textY }] }]}>
        Calorix
      </Animated.Text>

      {/* Subtitle */}
      <Animated.Text style={[styles.subtitle, { opacity: textOpacity }]}>
        Track smarter. Eat better.
      </Animated.Text>

      {/* Get Started button */}
      <Animated.View style={[styles.btnWrap, { opacity: btnOpacity }]}>
        <TouchableOpacity style={styles.btn} onPress={handleEnter} activeOpacity={0.8}>
          <Text style={styles.btnText}>Get Started</Text>
          <Ionicons name="arrow-forward" size={18} color="#fff" />
        </TouchableOpacity>
      </Animated.View>

    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },

  logoWrap: {
    width: 115,
    height: 115,
    borderRadius: 34,
    backgroundColor: '#4F46E5',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 26,
    shadowColor: '#4F46E5',
    shadowOpacity: 0.22,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 8 },
    elevation: 8,
  },

  title: {
    fontSize: 46,
    fontWeight: '900',
    color: '#111827',
    letterSpacing: -1,
  },

  subtitle: {
    marginTop: 8,
    fontSize: 16,
    color: '#6B7280',
    fontWeight: '500',
  },

  btnWrap: {
    position: 'absolute',
    bottom: 55,
    width: '78%',
  },

  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: '#4F46E5',
    paddingVertical: 16,
    borderRadius: 16,
  },

  btnText: {
    fontSize: 16,
    fontWeight: '800',
    color: '#fff',
  },
});