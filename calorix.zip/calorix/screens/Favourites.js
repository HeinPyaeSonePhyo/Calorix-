import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert,
} from 'react-native';
import { useFocusEffect, useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { getFavourites, toggleFavourite, getCustomFoods, addToLog } from '../utils/storage';
import baseFoods from '../data/foods';

export default function FavouritesScreen() {
  const [favourites, setFavourites] = useState([]);
  const navigation = useNavigation();

  const load = useCallback(async () => {
    const [favIds, customs] = await Promise.all([getFavourites(), getCustomFoods()]);
    const all = [...baseFoods, ...customs];
    const favFoods = all.filter((f) => favIds.includes(f.id));
    setFavourites(favFoods);
  }, []);

  useFocusEffect(load);

  const handleRemoveFav = async (food) => {
    await toggleFavourite(food.id);
    load();
  };

  const handleQuickLog = async (food) => {
    await addToLog({
      foodId: food.id,
      name: food.name,
      category: food.category,
      portion: food.portion,
      servings: 1,
      calories: food.calories,
      protein: food.protein,
      carbs: food.carbs,
      fat: food.fat,
    });
    Alert.alert('Logged!', `${food.name} added to today's log.`);
  };

  const calColor = (cal) => {
    if (cal < 150) return '#10B981';
    if (cal < 350) return '#4F46E5';
    if (cal < 500) return '#F59E0B';
    return '#EF4444';
  };

  const renderItem = ({ item }) => (
    <View style={styles.card}>
      <TouchableOpacity
        style={styles.cardMain}
        onPress={() => navigation.navigate('Library', { screen: 'FoodDetail', params: { food: item } })}
      >
        <View style={styles.cardLeft}>
          <Text style={styles.cardName}>{item.name}</Text>
          <Text style={styles.cardPortion}>{item.portion} · {item.category}</Text>
          <View style={styles.macroRow}>
            <Text style={styles.macroChip}>P: {item.protein}g</Text>
            <Text style={styles.macroChip}>C: {item.carbs}g</Text>
            <Text style={styles.macroChip}>F: {item.fat}g</Text>
          </View>
        </View>
        <View style={styles.cardRight}>
          <View style={[styles.calBadge, { backgroundColor: calColor(item.calories) + '20' }]}>
            <Text style={[styles.calText, { color: calColor(item.calories) }]}>{item.calories} kcal</Text>
          </View>
        </View>
      </TouchableOpacity>
      <View style={styles.cardActions}>
        <TouchableOpacity style={styles.quickLogBtn} onPress={() => handleQuickLog(item)}>
          <Ionicons name="add-circle-outline" size={16} color="#4F46E5" />
          <Text style={styles.quickLogText}>Quick Log</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.removeFavBtn} onPress={() => handleRemoveFav(item)}>
          <Ionicons name="heart-dislike-outline" size={16} color="#EF4444" />
          <Text style={styles.removeFavText}>Remove</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.heading}>Favourites</Text>
        <Text style={styles.subheading}>{favourites.length} saved foods</Text>
      </View>

      <FlatList
        data={favourites}
        keyExtractor={(item) => String(item.id)}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.emptyBox}>
            <Ionicons name="heart-outline" size={48} color="#D1D5DB" />
            <Text style={styles.emptyTitle}>No favourites yet</Text>
            <Text style={styles.emptyText}>
              Tap the heart icon on any food in the Library to save it here for quick access.
            </Text>
            <TouchableOpacity
              style={styles.goLibraryBtn}
              onPress={() => navigation.navigate('Library')}
            >
              <Text style={styles.goLibraryText}>Browse Library</Text>
            </TouchableOpacity>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { paddingHorizontal: 16, paddingTop: 52, paddingBottom: 12 },
  heading: { fontSize: 26, fontWeight: '800', color: '#111827' },
  subheading: { fontSize: 13, color: '#6B7280' },
  list: { paddingHorizontal: 16, paddingBottom: 20 },
  card: { backgroundColor: '#fff', borderRadius: 14, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 4, elevation: 1, overflow: 'hidden' },
  cardMain: { flexDirection: 'row', padding: 14 },
  cardLeft: { flex: 1 },
  cardName: { fontSize: 16, fontWeight: '700', color: '#111827', marginBottom: 2 },
  cardPortion: { fontSize: 12, color: '#6B7280', marginBottom: 6 },
  macroRow: { flexDirection: 'row', gap: 6 },
  macroChip: { fontSize: 11, color: '#6B7280', backgroundColor: '#F3F4F6', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  cardRight: { justifyContent: 'center', marginLeft: 8 },
  calBadge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 10 },
  calText: { fontSize: 14, fontWeight: '800' },
  cardActions: { flexDirection: 'row', borderTopWidth: 1, borderTopColor: '#F3F4F6' },
  quickLogBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, gap: 5, borderRightWidth: 1, borderRightColor: '#F3F4F6' },
  quickLogText: { fontSize: 13, fontWeight: '600', color: '#4F46E5' },
  removeFavBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, gap: 5 },
  removeFavText: { fontSize: 13, fontWeight: '600', color: '#EF4444' },
  emptyBox: { alignItems: 'center', paddingVertical: 60, paddingHorizontal: 32, gap: 10 },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: '#374151' },
  emptyText: { fontSize: 14, color: '#9CA3AF', textAlign: 'center', lineHeight: 20 },
  goLibraryBtn: { backgroundColor: '#4F46E5', paddingHorizontal: 24, paddingVertical: 12, borderRadius: 12, marginTop: 8 },
  goLibraryText: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
