import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { getFavourites, toggleFavourite, addToLog, deleteCustomFood } from '../utils/storage';

export default function FoodDetailScreen({ route, navigation }) {
  const { food } = route.params;
  const [isFav, setIsFav] = useState(false);
  const [servings, setServings] = useState('1');
  const [logged, setLogged] = useState(false);

  useEffect(() => {
    getFavourites().then((favs) => setIsFav(favs.includes(food.id)));
  }, []);

  const handleToggleFav = async () => {
    const updated = await toggleFavourite(food.id);
    setIsFav(updated.includes(food.id));
  };

  const qty = Math.max(parseFloat(servings) || 1, 0.5);
  const scaled = (val) => Math.round(val * qty);

  const handleLog = async () => {
    const s = parseFloat(servings);
    if (!s || s <= 0) {
      Alert.alert('Invalid', 'Please enter a valid number of servings.');
      return;
    }
    await addToLog({
      foodId: food.id,
      name: food.name,
      category: food.category,
      portion: food.portion,
      servings: s,
      calories: scaled(food.calories),
      protein: scaled(food.protein),
      carbs: scaled(food.carbs),
      fat: scaled(food.fat),
    });
    setLogged(true);
    Alert.alert('Logged!', `${food.name} (${s} serving${s !== 1 ? 's' : ''}) added to today's log.`, [
      { text: 'View Log', onPress: () => navigation.navigate('My Log') },
      { text: 'OK' },
    ]);
  };

  const handleDelete = () => {
    if (!food.custom) return;
    Alert.alert('Delete Food', `Delete "${food.name}" permanently?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete', style: 'destructive', onPress: async () => {
          await deleteCustomFood(food.id);
          navigation.goBack();
        }
      }
    ]);
  };

  const macro = (label, val, max, color) => (
    <View style={styles.macroCard} key={label}>
      <Text style={[styles.macroVal, { color }]}>{scaled(val)}g</Text>
      <Text style={styles.macroLabel}>{label}</Text>
      <View style={styles.macroBarBg}>
        <View style={[styles.macroBarFill, { width: `${Math.min(val / max, 1) * 100}%`, backgroundColor: color }]} />
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={22} color="#111827" />
        </TouchableOpacity>
        <TouchableOpacity onPress={handleToggleFav} style={styles.favBtn}>
          <Ionicons name={isFav ? 'heart' : 'heart-outline'} size={24} color={isFav ? '#EF4444' : '#9CA3AF'} />
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.content}>
        {/* Title */}
        <View style={styles.titleSection}>
          <View style={[styles.catBadge, { backgroundColor: '#EEF2FF' }]}>
            <Text style={styles.catText}>{food.category}</Text>
          </View>
          <Text style={styles.foodName}>{food.name}</Text>
          <Text style={styles.portionText}>per {food.portion}</Text>
          {food.custom && <View style={styles.customBadge}><Text style={styles.customText}>Custom</Text></View>}
        </View>

        {/* Calorie Hero */}
        <View style={styles.calHero}>
          <Text style={styles.calNumber}>{scaled(food.calories)}</Text>
          <Text style={styles.calLabel}>kcal</Text>
        </View>

        {/* Macros */}
        <View style={styles.macroRow}>
          {macro('Protein', food.protein, 50, '#4F46E5')}
          {macro('Carbs', food.carbs, 100, '#10B981')}
          {macro('Fat', food.fat, 40, '#F59E0B')}
        </View>

        {/* Servings Picker */}
        <View style={styles.servingCard}>
          <Text style={styles.servingTitle}>How many servings?</Text>
          <View style={styles.servingRow}>
            <TouchableOpacity
              style={styles.servingBtn}
              onPress={() => setServings(String(Math.max(0.5, qty - 0.5)))}
            >
              <Ionicons name="remove" size={22} color="#4F46E5" />
            </TouchableOpacity>
            <TextInput
              style={styles.servingInput}
              value={String(qty)}
              onChangeText={setServings}
              keyboardType="decimal-pad"
            />
            <TouchableOpacity
              style={styles.servingBtn}
              onPress={() => setServings(String(qty + 0.5))}
            >
              <Ionicons name="add" size={22} color="#4F46E5" />
            </TouchableOpacity>
          </View>
          <Text style={styles.servingNote}>
            Total: {scaled(food.calories)} kcal · {scaled(food.protein)}g P · {scaled(food.carbs)}g C · {scaled(food.fat)}g F
          </Text>
        </View>

        {/* Log Button */}
        <TouchableOpacity style={styles.logBtn} onPress={handleLog}>
          <Ionicons name="add-circle-outline" size={20} color="#fff" />
          <Text style={styles.logBtnText}>Log to Today</Text>
        </TouchableOpacity>

        {food.custom && (
          <TouchableOpacity style={styles.deleteBtn} onPress={handleDelete}>
            <Ionicons name="trash-outline" size={18} color="#EF4444" />
            <Text style={styles.deleteBtnText}>Delete This Food</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 8 },
  backBtn: { padding: 4 },
  favBtn: { padding: 4 },
  content: { padding: 16, paddingBottom: 40 },
  titleSection: { marginBottom: 16 },
  catBadge: { alignSelf: 'flex-start', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8, marginBottom: 8 },
  catText: { fontSize: 12, fontWeight: '700', color: '#4F46E5' },
  foodName: { fontSize: 28, fontWeight: '900', color: '#111827', marginBottom: 4 },
  portionText: { fontSize: 14, color: '#6B7280' },
  customBadge: { alignSelf: 'flex-start', backgroundColor: '#FEF3C7', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 6, marginTop: 6 },
  customText: { fontSize: 11, fontWeight: '700', color: '#D97706' },
  calHero: { backgroundColor: '#4F46E5', borderRadius: 20, padding: 24, alignItems: 'center', marginBottom: 14 },
  calNumber: { fontSize: 56, fontWeight: '900', color: '#fff' },
  calLabel: { fontSize: 18, color: 'rgba(255,255,255,0.7)', fontWeight: '600' },
  macroRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  macroCard: { flex: 1, backgroundColor: '#fff', borderRadius: 14, padding: 12, alignItems: 'center' },
  macroVal: { fontSize: 20, fontWeight: '800', marginBottom: 2 },
  macroLabel: { fontSize: 11, color: '#6B7280', marginBottom: 6 },
  macroBarBg: { height: 4, backgroundColor: '#E5E7EB', borderRadius: 2, width: '100%', overflow: 'hidden' },
  macroBarFill: { height: 4, borderRadius: 2 },
  servingCard: { backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 14 },
  servingTitle: { fontSize: 15, fontWeight: '700', color: '#111827', marginBottom: 12 },
  servingRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 16, marginBottom: 10 },
  servingBtn: { backgroundColor: '#EEF2FF', width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center' },
  servingInput: { fontSize: 24, fontWeight: '800', color: '#111827', textAlign: 'center', width: 80, borderBottomWidth: 2, borderBottomColor: '#4F46E5', paddingBottom: 4 },
  servingNote: { fontSize: 13, color: '#6B7280', textAlign: 'center' },
  logBtn: { backgroundColor: '#4F46E5', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, borderRadius: 14, gap: 8, marginBottom: 10 },
  logBtnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
  deleteBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 14, borderRadius: 14, gap: 6, borderWidth: 1, borderColor: '#FCA5A5', backgroundColor: '#FEF2F2' },
  deleteBtnText: { color: '#EF4444', fontWeight: '700', fontSize: 14 },
});
