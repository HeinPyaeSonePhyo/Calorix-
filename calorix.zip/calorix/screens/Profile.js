import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  TextInput, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { getProfile, saveProfile, setDailyGoal, getDailyGoal } from '../utils/storage';

const ACTIVITY_LEVELS = [
  { key: 'sedentary',  label: 'Sedentary',       desc: 'Little or no exercise',          multiplier: 1.2   },
  { key: 'light',      label: 'Lightly Active',   desc: '1–3 days/week exercise',         multiplier: 1.375 },
  { key: 'moderate',   label: 'Moderately Active', desc: '3–5 days/week exercise',        multiplier: 1.55  },
  { key: 'active',     label: 'Very Active',       desc: '6–7 days/week exercise',        multiplier: 1.725 },
  { key: 'extra',      label: 'Extra Active',      desc: 'Hard exercise + physical job',  multiplier: 1.9   },
];

const GOALS = [
  { key: 'lose',     label: 'Lose Weight',    icon: 'trending-down', adjust: -500 },
  { key: 'maintain', label: 'Maintain',       icon: 'remove',        adjust: 0    },
  { key: 'gain',     label: 'Gain Muscle',    icon: 'trending-up',   adjust: +300 },
];

// Mifflin-St Jeor BMR
function calcBMR(gender, weightKg, heightCm, age) {
  const base = 10 * weightKg + 6.25 * heightCm - 5 * age;
  return gender === 'male' ? base + 5 : base - 161;
}

export default function ProfileScreen() {
  const [age, setAge]           = useState('');
  const [heightCm, setHeightCm] = useState('');
  const [weightKg, setWeightKg] = useState('');
  const [gender, setGender]     = useState('male');
  const [activity, setActivity] = useState('moderate');
  const [goalKey, setGoalKey]   = useState('maintain');
  const [savedGoal, setSavedGoal] = useState(null);
  const [currentKcal, setCurrentKcal] = useState(2200);
  const [saved, setSaved]       = useState(false);

  const load = useCallback(async () => {
    const [profile, kcal] = await Promise.all([getProfile(), getDailyGoal()]);
    setCurrentKcal(kcal);
    if (profile) {
      setAge(String(profile.age));
      setHeightCm(String(profile.heightCm));
      setWeightKg(String(profile.weightKg));
      setGender(profile.gender);
      setActivity(profile.activity);
      setGoalKey(profile.goalKey);
      setSavedGoal(profile.calculatedKcal);
    }
  }, []);

  useFocusEffect(load);

  const getCalculated = () => {
    const a = parseInt(age), h = parseFloat(heightCm), w = parseFloat(weightKg);
    if (!a || !h || !w || a < 10 || a > 120 || h < 100 || h > 250 || w < 20 || w > 300) return null;
    const bmr = calcBMR(gender, w, h, a);
    const mult = ACTIVITY_LEVELS.find((l) => l.key === activity)?.multiplier || 1.55;
    const adjust = GOALS.find((g) => g.key === goalKey)?.adjust || 0;
    return Math.round(bmr * mult + adjust);
  };

  const calculated = getCalculated();

  const handleSave = async () => {
    if (!calculated) {
      Alert.alert('Incomplete', 'Please fill in all fields correctly:\n• Age: 10–120\n• Height: 100–250 cm\n• Weight: 20–300 kg');
      return;
    }
    const profile = { age: parseInt(age), heightCm: parseFloat(heightCm), weightKg: parseFloat(weightKg), gender, activity, goalKey, calculatedKcal: calculated };
    await Promise.all([saveProfile(profile), setDailyGoal(calculated)]);
    setSavedGoal(calculated);
    setCurrentKcal(calculated);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
    Alert.alert('Profile Saved!', `Your daily calorie goal has been set to ${calculated} kcal based on your profile.`);
  };

  const bmrPreview = (() => {
    const a = parseInt(age), h = parseFloat(heightCm), w = parseFloat(weightKg);
    if (!a || !h || !w) return null;
    return Math.round(calcBMR(gender, w, h, a));
  })();

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView style={styles.container} contentContainerStyle={styles.content}>
        <Text style={styles.heading}>My Profile</Text>
        

        {/* Current goal banner */}
        <View style={styles.currentBanner}>
          <Ionicons name="flame" size={20} color="#4F46E5" />
          <Text style={styles.currentText}>Current goal: <Text style={styles.currentKcal}>{currentKcal} kcal/day</Text></Text>
        </View>

        {/* Gender */}
        <Text style={styles.sectionTitle}>Gender</Text>
        <View style={styles.genderRow}>
          {['male', 'female'].map((g) => (
            <TouchableOpacity
              key={g}
              style={[styles.genderBtn, gender === g && styles.genderBtnActive]}
              onPress={() => setGender(g)}
            >
              <Ionicons
                name={g === 'male' ? 'male' : 'female'}
                size={20}
                color={gender === g ? '#fff' : '#6B7280'}
              />
              <Text style={[styles.genderText, gender === g && styles.genderTextActive]}>
                {g.charAt(0).toUpperCase() + g.slice(1)}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Age / Height / Weight */}
        <Text style={styles.sectionTitle}>Body Stats</Text>
        <View style={styles.statsRow}>
          <View style={styles.statField}>
            <Text style={styles.statLabel}>Age</Text>
            <View style={styles.statInputWrap}>
              <TextInput
                style={styles.statInput}
                value={age}
                onChangeText={setAge}
                keyboardType="numeric"
                placeholder="- -"
                placeholderTextColor="#9CA3AF"
                maxLength={3}
              />
              <Text style={styles.statUnit}>yrs</Text>
            </View>
          </View>
          <View style={styles.statField}>
            <Text style={styles.statLabel}>Height</Text>
            <View style={styles.statInputWrap}>
              <TextInput
                style={styles.statInput}
                value={heightCm}
                onChangeText={setHeightCm}
                keyboardType="numeric"
                placeholder="- -"
                placeholderTextColor="#9CA3AF"
                maxLength={5}
              />
              <Text style={styles.statUnit}>cm</Text>
            </View>
          </View>
          <View style={styles.statField}>
            <Text style={styles.statLabel}>Weight</Text>
            <View style={styles.statInputWrap}>
              <TextInput
                style={styles.statInput}
                value={weightKg}
                onChangeText={setWeightKg}
                keyboardType="numeric"
                placeholder="- -"
                placeholderTextColor="#9CA3AF"
                maxLength={5}
              />
              <Text style={styles.statUnit}>kg</Text>
            </View>
          </View>
        </View>

        {/* BMR preview */}
        {bmrPreview && (
          <View style={styles.bmrBox}>
            <Text style={styles.bmrLabel}>Your Basal Metabolic Rate (BMR)</Text>
            <Text style={styles.bmrValue}>{bmrPreview} <Text style={styles.bmrUnit}>kcal/day at rest</Text></Text>
          </View>
        )}

        {/* Activity Level */}
        <Text style={styles.sectionTitle}>Activity Level</Text>
        {ACTIVITY_LEVELS.map((lvl) => (
          <TouchableOpacity
            key={lvl.key}
            style={[styles.optionRow, activity === lvl.key && styles.optionRowActive]}
            onPress={() => setActivity(lvl.key)}
          >
            <View style={[styles.radioCircle, activity === lvl.key && styles.radioCircleActive]}>
              {activity === lvl.key && <View style={styles.radioDot} />}
            </View>
            <View style={styles.optionText}>
              <Text style={[styles.optionLabel, activity === lvl.key && { color: '#4F46E5' }]}>{lvl.label}</Text>
              <Text style={styles.optionDesc}>{lvl.desc} (×{lvl.multiplier})</Text>
            </View>
          </TouchableOpacity>
        ))}

        {/* Goal */}
        <Text style={styles.sectionTitle}>Your Goal</Text>
        <View style={styles.goalRow}>
          {GOALS.map((g) => (
            <TouchableOpacity
              key={g.key}
              style={[styles.goalBtn, goalKey === g.key && styles.goalBtnActive]}
              onPress={() => setGoalKey(g.key)}
            >
              <Ionicons name={g.icon} size={22} color={goalKey === g.key ? '#fff' : '#6B7280'} />
              <Text style={[styles.goalText, goalKey === g.key && styles.goalTextActive]}>{g.label}</Text>
              <Text style={[styles.goalAdjust, goalKey === g.key && { color: 'rgba(255,255,255,0.8)' }]}>
                {g.adjust === 0 ? 'TDEE' : g.adjust > 0 ? `+${g.adjust}` : `${g.adjust}`} kcal
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Live preview */}
        {calculated && (
          <View style={styles.previewCard}>
            <Text style={styles.previewTitle}>Recommended Daily Calories</Text>
            <Text style={styles.previewKcal}>{calculated}</Text>
            <Text style={styles.previewUnit}>kcal / day</Text>
            <View style={styles.previewBreakdown}>
              <Text style={styles.previewDetail}>BMR: {bmrPreview} kcal</Text>
              <Text style={styles.previewDetail}>×{ACTIVITY_LEVELS.find(l=>l.key===activity).multiplier} activity</Text>
              <Text style={styles.previewDetail}>
                {GOALS.find(g=>g.key===goalKey).adjust >= 0 ? '+' : ''}{GOALS.find(g=>g.key===goalKey).adjust} goal adjust
              </Text>
            </View>
          </View>
        )}


<TouchableOpacity
  style={[styles.saveBtn, !calculated && styles.saveBtnDisabled]}
  onPress={handleSave}
  disabled={!calculated}
>
  <Ionicons
    name={
      saved
        ? 'checkmark-circle'
        : savedGoal
        ? 'create-outline'
        : 'save-outline'
    }
    size={20}
    color="#fff"
  />

  <Text style={styles.saveBtnText}>
    {saved
      ? 'Updated!'
      : savedGoal
      ? 'Update Goal'
      : 'Save & Apply Goal'}
  </Text>
</TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  content: { padding: 16, paddingTop: 52, paddingBottom: 40 },
  heading: { fontSize: 26, fontWeight: '800', color: '#111827', marginBottom: 4 },
  subheading: { fontSize: 13, color: '#6B7280', lineHeight: 18, marginBottom: 16 },
  currentBanner: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#EEF2FF', borderRadius: 12, padding: 12, marginBottom: 20 },
  currentText: { fontSize: 14, color: '#374151' },
  currentKcal: { fontWeight: '800', color: '#4F46E5' },
  sectionTitle: { fontSize: 13, fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 10, marginTop: 6 },
  genderRow: { flexDirection: 'row', gap: 12, marginBottom: 20 },
  genderBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, borderRadius: 14, backgroundColor: '#fff', borderWidth: 2, borderColor: '#E5E7EB' },
  genderBtnActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  genderText: { fontSize: 15, fontWeight: '700', color: '#6B7280' },
  genderTextActive: { color: '#fff' },
  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  statField: { flex: 1 },
  statLabel: { fontSize: 12, fontWeight: '600', color: '#374151', marginBottom: 6 },
  statInputWrap: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 10, flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 10 },
  statInput: { flex: 1, fontSize: 16, fontWeight: '700', color: '#111827' },
  statUnit: { fontSize: 11, color: '#9CA3AF', fontWeight: '600' },
  bmrBox: { backgroundColor: '#F0FDF4', borderRadius: 12, padding: 12, marginBottom: 18, borderWidth: 1, borderColor: '#BBF7D0' },
  bmrLabel: { fontSize: 12, color: '#15803D', fontWeight: '600', marginBottom: 2 },
  bmrValue: { fontSize: 20, fontWeight: '900', color: '#15803D' },
  bmrUnit: { fontSize: 13, fontWeight: '400' },
  optionRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 12, padding: 12, marginBottom: 8, borderWidth: 1.5, borderColor: '#E5E7EB', gap: 12 },
  optionRowActive: { borderColor: '#4F46E5', backgroundColor: '#F5F3FF' },
  radioCircle: { width: 20, height: 20, borderRadius: 10, borderWidth: 2, borderColor: '#D1D5DB', alignItems: 'center', justifyContent: 'center' },
  radioCircleActive: { borderColor: '#4F46E5' },
  radioDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#4F46E5' },
  optionText: { flex: 1 },
  optionLabel: { fontSize: 14, fontWeight: '700', color: '#111827' },
  optionDesc: { fontSize: 12, color: '#6B7280', marginTop: 1 },
  goalRow: { flexDirection: 'row', gap: 8, marginBottom: 18 },
  goalBtn: { flex: 1, alignItems: 'center', padding: 12, borderRadius: 14, backgroundColor: '#fff', borderWidth: 2, borderColor: '#E5E7EB', gap: 4 },
  goalBtnActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  goalText: { fontSize: 11, fontWeight: '700', color: '#374151', textAlign: 'center' },
  goalTextActive: { color: '#fff' },
  goalAdjust: { fontSize: 10, color: '#9CA3AF', fontWeight: '600' },
  previewCard: { backgroundColor: '#4F46E5', borderRadius: 20, padding: 20, alignItems: 'center', marginBottom: 16 },
  previewTitle: { fontSize: 13, color: 'rgba(255,255,255,0.7)', fontWeight: '600', marginBottom: 4 },
  previewKcal: { fontSize: 52, fontWeight: '900', color: '#fff' },
  previewUnit: { fontSize: 14, color: 'rgba(255,255,255,0.7)', marginBottom: 12 },
  previewBreakdown: { flexDirection: 'row', gap: 12, flexWrap: 'wrap', justifyContent: 'center' },
  previewDetail: { fontSize: 11, color: 'rgba(255,255,255,0.6)', backgroundColor: 'rgba(255,255,255,0.15)', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  saveBtn: { backgroundColor: '#4F46E5', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, borderRadius: 14, gap: 8, marginBottom: 14 },
  saveBtnDisabled: { opacity: 0.4 },
  saveBtnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
  disclaimer: { fontSize: 11, color: '#9CA3AF', textAlign: 'center', lineHeight: 16 },
});
