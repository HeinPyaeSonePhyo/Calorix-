import React, { useState, useCallback, useMemo } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  TextInput, ScrollView,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import baseFoods from '../data/foods';
import { getCustomFoods, getFavourites } from '../utils/storage';

const CATEGORIES = ['All', 'Breakfast', 'Lunch', 'Dinner', 'Snack', 'Drink', 'Custom'];
const SORT_OPTIONS = ['Name A-Z', 'Name Z-A', 'Calories ↑', 'Calories ↓'];
const PAGE_SIZE = 10;

export default function FoodLibraryScreen({ navigation }) {
  const [allFoods, setAllFoods] = useState([]);
  const [favouriteIds, setFavouriteIds] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [sortBy, setSortBy] = useState('Name A-Z');
  const [showSort, setShowSort] = useState(false);
  const [page, setPage] = useState(1);

  const load = useCallback(async () => {
    const [customs, favs] = await Promise.all([getCustomFoods(), getFavourites()]);
    setAllFoods([...baseFoods, ...customs]);
    setFavouriteIds(favs);
    setPage(1);
  }, []);

  useFocusEffect(load);

  const filtered = useMemo(() => {
    let list = allFoods;
    if (category === 'Custom') list = list.filter((f) => f.custom);
    else if (category !== 'All') list = list.filter((f) => f.category === category);
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((f) => f.name.toLowerCase().includes(q));
    }
    list = [...list].sort((a, b) => {
      if (sortBy === 'Name A-Z') return a.name.localeCompare(b.name);
      if (sortBy === 'Name Z-A') return b.name.localeCompare(a.name);
      if (sortBy === 'Calories ↑') return a.calories - b.calories;
      if (sortBy === 'Calories ↓') return b.calories - a.calories;
      return 0;
    });
    return list;
  }, [allFoods, search, category, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const paged = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const handleSearch = (text) => {
    setSearch(text);
    setPage(1);
  };

  const handleCategory = (cat) => {
    setCategory(cat);
    setPage(1);
  };

  const calorieColor = (cal) => {
    if (cal < 150) return '#10B981';
    if (cal < 350) return '#4F46E5';
    if (cal < 500) return '#F59E0B';
    return '#EF4444';
  };

  const renderItem = ({ item }) => {
    const isFav = favouriteIds.includes(item.id);
    return (
      <TouchableOpacity
        style={styles.card}
        onPress={() => navigation.navigate('FoodDetail', { food: item })}
      >
        <View style={styles.cardTop}>
          <View style={styles.cardLeft}>
            <Text style={styles.cardName}>{item.name}</Text>
            <Text style={styles.cardPortion}>{item.portion}</Text>
          </View>
          <View style={styles.cardRight}>
            <View style={[styles.calBadge, { backgroundColor: calorieColor(item.calories) + '20' }]}>
              <Text style={[styles.calText, { color: calorieColor(item.calories) }]}>
                {item.calories} kcal
              </Text>
            </View>
            {isFav && <Ionicons name="heart" size={14} color="#EF4444" style={{ marginTop: 4 }} />}
          </View>
        </View>
        <View style={styles.macroRow}>
          <Text style={styles.macroChip}>P: {item.protein}g</Text>
          <Text style={styles.macroChip}>C: {item.carbs}g</Text>
          <Text style={styles.macroChip}>F: {item.fat}g</Text>
          <View style={[styles.catBadge, { backgroundColor: '#EEF2FF' }]}>
            <Text style={styles.catText}>{item.category}</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.heading}>Food Library</Text>
          <Text style={styles.subheading}>{filtered.length} foods found</Text>
        </View>
        <TouchableOpacity style={styles.addBtn} onPress={() => navigation.navigate('AddFood')}>
          <Ionicons name="add" size={22} color="#fff" />
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={styles.searchBox}>
        <Ionicons name="search" size={18} color="#9CA3AF" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search foods..."
          value={search}
          onChangeText={handleSearch}
          clearButtonMode="while-editing"
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => handleSearch('')}>
            <Ionicons name="close-circle" size={18} color="#9CA3AF" />
          </TouchableOpacity>
        )}
      </View>

      {/* Category filter */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll} contentContainerStyle={styles.filterRow}>
        {CATEGORIES.map((cat) => (
          <TouchableOpacity
            key={cat}
            style={[styles.filterChip, category === cat && styles.filterChipActive]}
            onPress={() => handleCategory(cat)}
          >
            <Text style={[styles.filterText, category === cat && styles.filterTextActive]}>{cat}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Sort */}
      <TouchableOpacity style={styles.sortRow} onPress={() => setShowSort(!showSort)}>
        <Ionicons name="swap-vertical" size={16} color="#4F46E5" />
        <Text style={styles.sortLabel}>Sort: {sortBy}</Text>
        <Ionicons name={showSort ? 'chevron-up' : 'chevron-down'} size={16} color="#4F46E5" />
      </TouchableOpacity>
      {showSort && (
        <View style={styles.sortDropdown}>
          {SORT_OPTIONS.map((opt) => (
            <TouchableOpacity key={opt} style={styles.sortOption} onPress={() => { setSortBy(opt); setShowSort(false); setPage(1); }}>
              <Text style={[styles.sortOptionText, sortBy === opt && styles.sortOptionActive]}>{opt}</Text>
              {sortBy === opt && <Ionicons name="checkmark" size={16} color="#4F46E5" />}
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* List */}
      <FlatList
        data={paged}
        keyExtractor={(item) => String(item.id)}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        ListEmptyComponent={<Text style={styles.empty}>No foods match your search.</Text>}
      />

      {/* Pagination */}
      {totalPages > 1 && (
        <View style={styles.pagination}>
          <TouchableOpacity
            style={[styles.pageBtn, page === 1 && styles.pageBtnDisabled]}
            onPress={() => page > 1 && setPage(page - 1)}
          >
            <Ionicons name="chevron-back" size={18} color={page === 1 ? '#D1D5DB' : '#4F46E5'} />
          </TouchableOpacity>
          <Text style={styles.pageText}>Page {page} of {totalPages}</Text>
          <TouchableOpacity
            style={[styles.pageBtn, page === totalPages && styles.pageBtnDisabled]}
            onPress={() => page < totalPages && setPage(page + 1)}
          >
            <Ionicons name="chevron-forward" size={18} color={page === totalPages ? '#D1D5DB' : '#4F46E5'} />
          </TouchableOpacity>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 10 },
  heading: { fontSize: 26, fontWeight: '800', color: '#111827' },
  subheading: { fontSize: 13, color: '#6B7280' },
  addBtn: { backgroundColor: '#4F46E5', width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  searchBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', marginHorizontal: 16, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10, marginBottom: 10, gap: 8, borderWidth: 1, borderColor: '#E5E7EB' },
  searchInput: { flex: 1, fontSize: 15, color: '#111827' },
  filterScroll: { marginBottom: 8, height: 46, flexGrow: 0 },
  filterRow: { paddingHorizontal: 16, gap: 8, alignItems: 'center' },
  filterChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: '#fff', borderWidth: 1, borderColor: '#E5E7EB', height: 34, justifyContent: 'center' },
  filterChipActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  filterText: { fontSize: 13, color: '#6B7280', fontWeight: '600' },
  filterTextActive: { color: '#fff' },
  sortRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 6, gap: 6 },
  sortLabel: { flex: 1, fontSize: 13, fontWeight: '600', color: '#4F46E5' },
  sortDropdown: { backgroundColor: '#fff', marginHorizontal: 16, borderRadius: 12, borderWidth: 1, borderColor: '#E5E7EB', marginBottom: 6, overflow: 'hidden' },
  sortOption: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 12, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  sortOptionText: { fontSize: 14, color: '#374151' },
  sortOptionActive: { color: '#4F46E5', fontWeight: '700' },
  list: { paddingHorizontal: 16, paddingBottom: 10 },
  card: { backgroundColor: '#fff', borderRadius: 14, padding: 14, marginBottom: 10, shadowColor: '#000', shadowOpacity: 0.04, shadowRadius: 4, elevation: 1 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  cardLeft: { flex: 1, marginRight: 8 },
  cardName: { fontSize: 16, fontWeight: '700', color: '#111827' },
  cardPortion: { fontSize: 12, color: '#6B7280', marginTop: 2 },
  cardRight: { alignItems: 'flex-end' },
  calBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  calText: { fontSize: 13, fontWeight: '700' },
  macroRow: { flexDirection: 'row', gap: 6, alignItems: 'center', flexWrap: 'wrap' },
  macroChip: { fontSize: 11, color: '#6B7280', backgroundColor: '#F9FAFB', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  catBadge: { marginLeft: 'auto', paddingHorizontal: 8, paddingVertical: 2, borderRadius: 6 },
  catText: { fontSize: 11, color: '#4F46E5', fontWeight: '600' },
  empty: { textAlign: 'center', color: '#9CA3AF', fontSize: 15, paddingVertical: 40 },
  pagination: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, gap: 16, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  pageBtn: { padding: 6 },
  pageBtnDisabled: { opacity: 0.4 },
  pageText: { fontSize: 14, fontWeight: '600', color: '#374151' },
});
