import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, Alert,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { getTodayLog, getDailyGoal, removeFromLog } from '../utils/storage';

const { width } = Dimensions.get('window');
const RING = width * 0.42;

export default function DashboardScreen() {
  const [log, setLog] = useState([]);
  const [goal, setGoal] = useState(2200);

  const load = useCallback(async () => {
    const [l, g] = await Promise.all([getTodayLog(), getDailyGoal()]);
    setLog(l);
    setGoal(g);
  }, []);

  useFocusEffect(load);

  const totals = log.reduce(
    (acc, e) => ({
      calories: acc.calories + e.calories,
      protein: acc.protein + e.protein,
      carbs: acc.carbs + e.carbs,
      fat: acc.fat + e.fat,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const pct = Math.min(totals.calories / goal, 1);
  const remaining = Math.max(goal - totals.calories, 0);
  const over = totals.calories > goal;
  const ringColor = over ? '#EF4444' : pct > 0.85 ? '#F59E0B' : '#4F46E5';

  const handleRemove = (logId, name) => {
    Alert.alert('Remove entry', `Remove ${name} from today?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove', style: 'destructive', onPress: async () => {
          await removeFromLog(logId);
          load();
        },
      },
    ]);
  };

  const today = new Date().toLocaleDateString('en-GB', { weekday: 'long', day: 'numeric', month: 'long' });

  const grouped = log.reduce((acc, e) => {
    const cat = e.category || 'Other';
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(e);
    return acc;
  }, {});

  const macroBar = (label, grams, color, reference) => {
    const p = reference > 0 ? Math.min(grams / reference, 1) : 0;
    return (
      <View style={styles.macroItem} key={label}>
        <View style={styles.macroLabelRow}>
          <Text style={styles.macroLabel}>{label}</Text>
          <Text style={styles.macroValue}>{grams}g</Text>
        </View>
        <View style={styles.macroBarBg}>
          <View style={[styles.macroBarFill, { width: `${p * 100}%`, backgroundColor: color }]} />
        </View>
      </View>
    );
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <Text style={styles.greeting}>Today</Text>
      <Text style={styles.date}>{today}</Text>

      <View style={styles.ringContainer}>
        <View style={[styles.ring, { borderColor: ringColor }]}>
          <Text style={[styles.ringCalories, { color: ringColor }]}>{totals.calories}</Text>
          <Text style={styles.ringLabel}>kcal eaten</Text>
        </View>
        <View style={styles.ringInfo}>
          <View style={styles.ringInfoItem}>
            <Ionicons name="flame" size={18} color="#4F46E5" />
            <Text style={styles.ringInfoLabel}>Goal</Text>
            <Text style={styles.ringInfoValue}>{goal}</Text>
          </View>
          <View style={styles.ringInfoItem}>
            <Ionicons name={over ? 'arrow-up' : 'arrow-down'} size={18} color={over ? '#EF4444' : '#10B981'} />
            <Text style={styles.ringInfoLabel}>{over ? 'Over' : 'Left'}</Text>
            <Text style={[styles.ringInfoValue, { color: over ? '#EF4444' : '#10B981' }]}>
              {over ? totals.calories - goal : remaining}
            </Text>
          </View>
        </View>
      </View>

      <View style={styles.progressBg}>
        <View style={[styles.progressFill, { width: `${pct * 100}%`, backgroundColor: ringColor }]} />
      </View>
      <Text style={styles.progressHint}>
        {over
          ? `${totals.calories - goal} kcal over your daily goal`
          : `${remaining} kcal remaining · Update goal in Profile tab`}
      </Text>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Macronutrients</Text>
        {macroBar('Protein', totals.protein, '#4F46E5', 150)}
        {macroBar('Carbs', totals.carbs, '#10B981', 300)}
        {macroBar('Fat', totals.fat, '#F59E0B', 80)}
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Today's Food Log</Text>
        {log.length === 0 ? (
          <View style={styles.emptyBox}>
            <Ionicons name="restaurant-outline" size={32} color="#D1D5DB" />
            <Text style={styles.emptyText}>No food logged yet.{'\n'}Go to Library to add food.</Text>
          </View>
        ) : (
          Object.entries(grouped).map(([cat, entries]) => (
            <View key={cat}>
              <Text style={styles.mealCategory}>{cat}</Text>
              {entries.map((e) => (
                <View key={e.logId} style={styles.logEntry}>
                  <View style={styles.logEntryLeft}>
                    <Text style={styles.logEntryName}>{e.name}</Text>
                    <Text style={styles.logEntryPortion}>{e.servings}x {e.portion}</Text>
                  </View>
                  <View style={styles.logEntryRight}>
                    <Text style={styles.logEntryKcal}>{e.calories} kcal</Text>
                    <TouchableOpacity onPress={() => handleRemove(e.logId, e.name)}>
                      <Ionicons name="trash-outline" size={18} color="#EF4444" />
                    </TouchableOpacity>
                  </View>
                </View>
              ))}
            </View>
          ))
        )}
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  content: { padding: 16, paddingTop: 52, paddingBottom: 30 },
  greeting: { fontSize: 26, fontWeight: '800', color: '#111827' },
  date: { fontSize: 14, color: '#6B7280', marginBottom: 18 },
  ringContainer: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: 12 },
  ring: {
    width: RING, height: RING, borderRadius: RING / 2,
    borderWidth: 8, alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#fff', marginRight: 24,
  },
  ringCalories: { fontSize: 32, fontWeight: '900' },
  ringLabel: { fontSize: 12, color: '#6B7280', fontWeight: '600' },
  ringInfo: { gap: 20 },
  ringInfoItem: { alignItems: 'center', gap: 2 },
  ringInfoLabel: { fontSize: 11, color: '#6B7280' },
  ringInfoValue: { fontSize: 18, fontWeight: '800', color: '#111827' },
  progressBg: { height: 8, backgroundColor: '#E5E7EB', borderRadius: 4, overflow: 'hidden', marginBottom: 6 },
  progressFill: { height: 8, borderRadius: 4 },
  progressHint: { fontSize: 12, color: '#9CA3AF', textAlign: 'center', marginBottom: 16 },
  card: { backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 14, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  cardTitle: { fontSize: 16, fontWeight: '700', color: '#111827', marginBottom: 12 },
  macroItem: { marginBottom: 10 },
  macroLabelRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 4 },
  macroLabel: { fontSize: 13, color: '#374151', fontWeight: '600' },
  macroValue: { fontSize: 13, color: '#6B7280' },
  macroBarBg: { height: 8, backgroundColor: '#E5E7EB', borderRadius: 4, overflow: 'hidden' },
  macroBarFill: { height: 8, borderRadius: 4 },
  emptyBox: { alignItems: 'center', paddingVertical: 16, gap: 8 },
  emptyText: { color: '#9CA3AF', fontSize: 14, textAlign: 'center', lineHeight: 20 },
  mealCategory: { fontSize: 13, fontWeight: '700', color: '#4F46E5', marginTop: 10, marginBottom: 4, textTransform: 'uppercase', letterSpacing: 0.5 },
  logEntry: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: '#F3F4F6' },
  logEntryLeft: { flex: 1 },
  logEntryName: { fontSize: 14, fontWeight: '600', color: '#111827' },
  logEntryPortion: { fontSize: 12, color: '#6B7280' },
  logEntryRight: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logEntryKcal: { fontSize: 14, fontWeight: '700', color: '#4F46E5' },
});