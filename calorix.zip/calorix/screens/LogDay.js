import React, { useState, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Alert, ScrollView,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons';
import { getTodayLog, getDailyGoal, removeFromLog } from '../utils/storage';

const MEAL_FILTERS = ['All', 'Breakfast', 'Lunch', 'Dinner', 'Snack', 'Drink', 'Other'];

export default function LogScreen() {
  const [log, setLog] = useState([]);
  const [goal, setGoal] = useState(2200);
  const [filter, setFilter] = useState('All');

  const load = useCallback(async () => {
    const [l, g] = await Promise.all([getTodayLog(), getDailyGoal()]);
    setLog(l);
    setGoal(g);
  }, []);

  useFocusEffect(load);

  const filtered = filter === 'All' ? log : log.filter((e) => e.category === filter);

  const totals = log.reduce(
    (acc, e) => ({
      calories: acc.calories + e.calories,
      protein: acc.protein + e.protein,
      carbs: acc.carbs + e.carbs,
      fat: acc.fat + e.fat,
    }),
    { calories: 0, protein: 0, carbs: 0, fat: 0 }
  );

  const handleRemove = (logId, name) => {
    Alert.alert('Remove entry', `Remove "${name}" from today?`, [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove', style: 'destructive', onPress: async () => {
          await removeFromLog(logId);
          load();
        }
      }
    ]);
  };

  const pct = Math.min(totals.calories / goal, 1);
  const over = totals.calories > goal;

  const renderItem = ({ item }) => (
    <View style={styles.entry}>
      <View style={styles.entryLeft}>
        <Text style={styles.entryName}>{item.name}</Text>
        <Text style={styles.entryDetail}>
          {item.servings}× {item.portion} · {item.category}
        </Text>
        <View style={styles.macroRow}>
          <Text style={styles.macroChip}>P {item.protein}g</Text>
          <Text style={styles.macroChip}>C {item.carbs}g</Text>
          <Text style={styles.macroChip}>F {item.fat}g</Text>
        </View>
      </View>
      <View style={styles.entryRight}>
        <Text style={styles.entryKcal}>{item.calories}</Text>
        <Text style={styles.entryKcalLabel}>kcal</Text>
        <TouchableOpacity onPress={() => handleRemove(item.logId, item.name)} style={{ marginTop: 6 }}>
          <Ionicons name="trash-outline" size={18} color="#EF4444" />
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.heading}>My Log</Text>
        <Text style={styles.subheading}>{log.length} entries today</Text>
      </View>

      {/* Summary */}
      <View style={styles.summaryCard}>
        <View style={styles.summaryRow}>
          <View style={styles.summaryItem}>
            <Text style={styles.summaryValue}>{totals.calories}</Text>
            <Text style={styles.summaryLabel}>Eaten</Text>
          </View>
          <Ionicons name="remove" size={20} color="#9CA3AF" />
          <View style={styles.summaryItem}>
            <Text style={styles.summaryValue}>{goal}</Text>
            <Text style={styles.summaryLabel}>Goal</Text>
          </View>
          <Ionicons name="remove" size={20} color="#9CA3AF" />
          <View style={styles.summaryItem}>
            <Text style={[styles.summaryValue, { color: over ? '#EF4444' : '#10B981' }]}>
              {over ? '+' : ''}{totals.calories - goal}
            </Text>
            <Text style={styles.summaryLabel}>{over ? 'Over' : 'Balance'}</Text>
          </View>
        </View>
        <View style={styles.progressBg}>
          <View style={[styles.progressFill, { width: `${pct * 100}%`, backgroundColor: over ? '#EF4444' : '#4F46E5' }]} />
        </View>
        <View style={styles.macroSummaryRow}>
          <Text style={styles.macroSummaryItem}><Text style={{ color: '#4F46E5', fontWeight: '700' }}>P</Text> {totals.protein}g</Text>
          <Text style={styles.macroSummaryItem}><Text style={{ color: '#10B981', fontWeight: '700' }}>C</Text> {totals.carbs}g</Text>
          <Text style={styles.macroSummaryItem}><Text style={{ color: '#F59E0B', fontWeight: '700' }}>F</Text> {totals.fat}g</Text>
        </View>
      </View>

      {/* Meal filter */}
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.filterScroll} contentContainerStyle={styles.filterRow}>
        {MEAL_FILTERS.map((f) => (
          <TouchableOpacity
            key={f}
            style={[styles.chip, filter === f && styles.chipActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.chipText, filter === f && styles.chipTextActive]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={(item) => String(item.logId)}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.emptyBox}>
            <Ionicons name="restaurant-outline" size={40} color="#D1D5DB" />
            <Text style={styles.emptyText}>
              {log.length === 0 ? 'No food logged today.\nGo to Library to add food.' : 'No entries in this category.'}
            </Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { paddingHorizontal: 16, paddingTop: 52, paddingBottom: 12 },
  heading: { fontSize: 26, fontWeight: '800', color: '#111827' },
  subheading: { fontSize: 13, color: '#6B7280' },
  summaryCard: { backgroundColor: '#fff', marginHorizontal: 16, borderRadius: 16, padding: 16, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 },
  summaryRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', marginBottom: 12 },
  summaryItem: { alignItems: 'center' },
  summaryValue: { fontSize: 22, fontWeight: '900', color: '#111827' },
  summaryLabel: { fontSize: 11, color: '#6B7280', marginTop: 2 },
  progressBg: { height: 8, backgroundColor: '#E5E7EB', borderRadius: 4, marginBottom: 10, overflow: 'hidden' },
  progressFill: { height: 8, borderRadius: 4 },
  macroSummaryRow: { flexDirection: 'row', justifyContent: 'space-around' },
  macroSummaryItem: { fontSize: 13, color: '#374151' },
  filterScroll: { marginBottom: 6, height: 44, flexGrow: 0 },
  filterRow: { paddingHorizontal: 16, gap: 8, alignItems: 'center' },
  chip: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20, backgroundColor: '#fff', borderWidth: 1, borderColor: '#E5E7EB', height: 32, justifyContent: 'center' },
  chipActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  chipText: { fontSize: 12, color: '#6B7280', fontWeight: '600' },
  chipTextActive: { color: '#fff' },
  list: { paddingHorizontal: 16, paddingBottom: 20 },
  entry: { backgroundColor: '#fff', borderRadius: 14, padding: 14, marginBottom: 10, flexDirection: 'row', alignItems: 'flex-start', shadowColor: '#000', shadowOpacity: 0.03, shadowRadius: 2, elevation: 1 },
  entryLeft: { flex: 1 },
  entryName: { fontSize: 15, fontWeight: '700', color: '#111827' },
  entryDetail: { fontSize: 12, color: '#6B7280', marginTop: 2, marginBottom: 6 },
  macroRow: { flexDirection: 'row', gap: 6 },
  macroChip: { fontSize: 11, color: '#6B7280', backgroundColor: '#F3F4F6', paddingHorizontal: 6, paddingVertical: 2, borderRadius: 6 },
  entryRight: { alignItems: 'flex-end', marginLeft: 8 },
  entryKcal: { fontSize: 20, fontWeight: '900', color: '#4F46E5' },
  entryKcalLabel: { fontSize: 10, color: '#6B7280' },
  emptyBox: { alignItems: 'center', paddingVertical: 50, gap: 12 },
  emptyText: { color: '#9CA3AF', fontSize: 14, textAlign: 'center', lineHeight: 20 },
});