import React, { useState } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TextInput,
  TouchableOpacity, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { saveCustomFood } from '../utils/storage';

const CATEGORIES = ['Breakfast', 'Lunch', 'Dinner', 'Snack', 'Drink'];

export default function AddFoodScreen({ navigation }) {
  const [name, setName] = useState('');
  const [category, setCategory] = useState('Snack');
  const [portion, setPortion] = useState('');
  const [calories, setCalories] = useState('');
  const [protein, setProtein] = useState('');
  const [carbs, setCarbs] = useState('');
  const [fat, setFat] = useState('');
  const [saving, setSaving] = useState(false);

  const validate = () => {
    if (!name.trim()) return 'Please enter a food name.';
    if (!portion.trim()) return 'Please describe the portion size.';
    const cal = parseInt(calories);
    if (!cal || cal < 1 || cal > 5000) return 'Please enter valid calories (1–5000).';
    return null;
  };

  const handleSave = async () => {
    const err = validate();
    if (err) { Alert.alert('Validation Error', err); return; }
    setSaving(true);
    await saveCustomFood({
      name: name.trim(),
      category,
      portion: portion.trim(),
      calories: parseInt(calories) || 0,
      protein: parseFloat(protein) || 0,
      carbs: parseFloat(carbs) || 0,
      fat: parseFloat(fat) || 0,
    });
    setSaving(false);
    Alert.alert('Saved!', `"${name.trim()}" has been added to your food library.`, [
      { text: 'Add Another', onPress: () => { setName(''); setPortion(''); setCalories(''); setProtein(''); setCarbs(''); setFat(''); } },
      { text: 'Go to Library', onPress: () => navigation.navigate('FoodLibrary') },
    ]);
  };

  const field = (label, value, onChange, opts = {}) => (
    <View style={styles.field}>
      <Text style={styles.label}>{label}</Text>
      <TextInput
        style={styles.input}
        value={value}
        onChangeText={onChange}
        placeholder={opts.placeholder || ''}
        keyboardType={opts.numeric ? 'decimal-pad' : 'default'}
        placeholderTextColor="#9CA3AF"
      />
    </View>
  );

  const autoCalc = () => {
    const p = parseFloat(protein) || 0;
    const c = parseFloat(carbs) || 0;
    const f = parseFloat(fat) || 0;
    const est = Math.round(p * 4 + c * 4 + f * 9);
    if (est > 0) setCalories(String(est));
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => navigation.goBack()}>
            <Ionicons name="arrow-back" size={22} color="#111827" />
          </TouchableOpacity>
          <Text style={styles.heading}>Add Custom Food</Text>
          <View style={{ width: 22 }} />
        </View>

        <ScrollView contentContainerStyle={styles.content}>
          <Text style={styles.sectionTitle}>Food Details</Text>

          {field('Food Name *', name, setName, { placeholder: 'e.g. Homemade Granola' })}
          {field('Portion Size *', portion, setPortion, { placeholder: 'e.g. 1 cup (80g)' })}

          <Text style={styles.label}>Category</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }} contentContainerStyle={styles.catRow}>
            {CATEGORIES.map((cat) => (
              <TouchableOpacity
                key={cat}
                style={[styles.catChip, category === cat && styles.catChipActive]}
                onPress={() => setCategory(cat)}
              >
                <Text style={[styles.catChipText, category === cat && styles.catChipTextActive]}>{cat}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <Text style={styles.sectionTitle}>Nutrition (per portion)</Text>

          <View style={styles.macroFieldRow}>
            <View style={[styles.field, { flex: 1 }]}>
              <Text style={[styles.label, { color: '#4F46E5' }]}>Protein (g)</Text>
              <TextInput style={styles.input} value={protein} onChangeText={setProtein} keyboardType="decimal-pad" placeholder="0" placeholderTextColor="#9CA3AF" onBlur={autoCalc} />
            </View>
            <View style={[styles.field, { flex: 1 }]}>
              <Text style={[styles.label, { color: '#10B981' }]}>Carbs (g)</Text>
              <TextInput style={styles.input} value={carbs} onChangeText={setCarbs} keyboardType="decimal-pad" placeholder="0" placeholderTextColor="#9CA3AF" onBlur={autoCalc} />
            </View>
            <View style={[styles.field, { flex: 1 }]}>
              <Text style={[styles.label, { color: '#F59E0B' }]}>Fat (g)</Text>
              <TextInput style={styles.input} value={fat} onChangeText={setFat} keyboardType="decimal-pad" placeholder="0" placeholderTextColor="#9CA3AF" onBlur={autoCalc} />
            </View>
          </View>

          <View style={styles.calRow}>
            <View style={[styles.field, { flex: 1 }]}>
              <Text style={styles.label}>Calories (kcal) *</Text>
              <TextInput style={[styles.input, styles.calInput]} value={calories} onChangeText={setCalories} keyboardType="decimal-pad" placeholder="e.g. 350" placeholderTextColor="#9CA3AF" />
            </View>
            <TouchableOpacity style={styles.calcBtn} onPress={autoCalc}>
              <Ionicons name="calculator-outline" size={18} color="#4F46E5" />
              <Text style={styles.calcBtnText}>Auto</Text>
            </TouchableOpacity>
          </View>

          <Text style={styles.hint}>💡 Tap "Auto" to calculate calories from macros (4 kcal/g protein & carbs, 9 kcal/g fat)</Text>

          <TouchableOpacity
            style={[styles.saveBtn, saving && styles.saveBtnDisabled]}
            onPress={handleSave}
            disabled={saving}
          >
            <Ionicons name="checkmark-circle" size={20} color="#fff" />
            <Text style={styles.saveBtnText}>{saving ? 'Saving…' : 'Save Food'}</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 12 },
  heading: { fontSize: 18, fontWeight: '800', color: '#111827' },
  content: { padding: 16, paddingBottom: 40 },
  sectionTitle: { fontSize: 13, fontWeight: '700', color: '#6B7280', textTransform: 'uppercase', letterSpacing: 0.8, marginBottom: 12, marginTop: 4 },
  field: { marginBottom: 14 },
  label: { fontSize: 14, fontWeight: '600', color: '#374151', marginBottom: 6 },
  input: { backgroundColor: '#fff', borderWidth: 1, borderColor: '#E5E7EB', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 12, fontSize: 15, color: '#111827' },
  calInput: { borderColor: '#4F46E5', borderWidth: 2 },
  catRow: { gap: 8, paddingVertical: 2 },
  catChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: '#fff', borderWidth: 1, borderColor: '#E5E7EB' },
  catChipActive: { backgroundColor: '#4F46E5', borderColor: '#4F46E5' },
  catChipText: { fontSize: 13, color: '#6B7280', fontWeight: '600' },
  catChipTextActive: { color: '#fff' },
  macroFieldRow: { flexDirection: 'row', gap: 10, marginBottom: 0 },
  calRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 10, marginBottom: 6 },
  calcBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: '#EEF2FF', paddingHorizontal: 12, paddingVertical: 14, borderRadius: 10, marginBottom: 14 },
  calcBtnText: { fontSize: 13, color: '#4F46E5', fontWeight: '700' },
  hint: { fontSize: 12, color: '#9CA3AF', marginBottom: 20, lineHeight: 18 },
  saveBtn: { backgroundColor: '#4F46E5', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, borderRadius: 14, gap: 8 },
  saveBtnDisabled: { opacity: 0.6 },
  saveBtnText: { color: '#fff', fontWeight: '800', fontSize: 16 },
});
